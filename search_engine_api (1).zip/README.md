# s-search

A simple Flask-based search API built for learning purposes.
