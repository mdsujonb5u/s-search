from flask import Flask, request, jsonify
import json

app = Flask(__name__)

# ডেটা লোড
with open('data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# সার্চ API
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify({'error': 'No query provided'}), 400

    results = []
    for item in data:
        if query in item['title'].lower() or query in item['description'].lower():
            results.append(item)

    return jsonify({'results': results, 'count': len(results)})

if __name__ == '__main__':
    app.run(debug=True)
